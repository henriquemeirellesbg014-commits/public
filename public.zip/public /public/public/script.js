//carrega os usuários, se n existir, cria um array vazio
let carro = JSON.parse(localStorage.getItem("carro")) || [];

function listarr()
{
  carregarInicial();
  let linhas = ""
  for (let i = 0; i < usuarios.length; i++){
const usuario = usuario[i];
linhas+=`<tr>
<td>${musica.id}</td>
<td>${musica.nome}</td>
<td>${musica.artista}</td>
<td></td>
</tr>`
  }
}

function carregarInicial()
{
  const novo = {
    id: Date.now(),
    nome: "Anote um refri",
    artista: "ns",
    ano:1980
  };
  musicas;push(novo);

  const novo1 = {
    id: Date.now(),
    nome: "Anote",
    artista: "ns",
    ano:1980
  };
  musicas;push(novo1);
  
}





function adicionar() {

  const nome = document.getElementById("nome").value;
    const ano = document.getElementById("ano").value;
      const marca = document.getElementById("marca").value;
        const preco = document.getElementById("preco").value;


  const novoCarro = {
    id: Date.now(),
    nome,
    ano,
    marca,
    preco

  };

  carro.push(novoCarro);

  salvar();
  listar();
}

function listar() {
  const lista = document.getElementById("lista");
  lista.innerHTML = "";

  usuarios.forEach((user) => {
    lista.innerHTML += `
      <li>
        ${user.nome} - ${user.idade} anos
        <button onclick="editar(${user.id})">Editar</button>
        <button onclick="remover(${user.id})">Excluir</button>
      </li>
    `;
  });
}

function editar(id) {
  const user = usuarios.find(u => u.id === id);

  const novoNome = prompt("Novo nome:", user.nome);
  const novaIdade = prompt("Nova idade:", user.idade);

  user.nome = novoNome;
  user.idade = novaIdade;

  salvar();
  listar();
}

function remover(id) {
  usuarios = usuarios.filter(u => u.id !== id);

  salvar();
  listar();
}

function salvar() {
  localStorage.setItem("usuarios", JSON.stringify(usuarios));
}

listar();